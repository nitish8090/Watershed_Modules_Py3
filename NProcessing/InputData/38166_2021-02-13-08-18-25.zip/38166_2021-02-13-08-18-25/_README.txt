Weater data requested on 2/13/2021 8:18 AM.

South Latitude: 23.4339
West Longitude: 72.7912
North Latitude: 24.4706
East Longitude: 73.8734
Number of Weather Stations: 12

Start Date: 1/1/2000
End Date: 7/31/2014

Data Collected:
Temperature (C): Yes
Precipitation (mm): Yes
Wind (m/s): Yes
Relative Humidity (fraction): Yes
Solar (MJ/m^2): Yes

Generate SWAT Files? Yes
Generate CSV File? Yes
